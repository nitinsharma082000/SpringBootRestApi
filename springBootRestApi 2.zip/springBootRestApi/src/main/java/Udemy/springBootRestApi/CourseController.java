package Udemy.springBootRestApi;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CourseController {

	
	@RequestMapping("/courses")
	public List<Course> retrieveAllCourses(){
		
		return Arrays.asList(
				new Course(1,"Learn AWS","IN 28 MINUTES"),
				new Course(2,"Learn DEVOPS","IN 28 MINUTES"),
				new Course(3,"Learn OOPS","IN 28 MINUTES"),
				new Course(3,"Learn OOPS","IN 55 MINUTES"),
				new Course(3,"Learn OOPS","IN 45 MINUTES"),
				new Course(3,"Learn OOPS","IN 35 MINUTES"));
		
	}

}
