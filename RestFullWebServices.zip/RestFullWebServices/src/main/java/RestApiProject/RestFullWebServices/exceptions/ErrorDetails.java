package RestApiProject.RestFullWebServices.exceptions;

import java.time.LocalDate;

public class ErrorDetails {
	
	
	private LocalDate timestamp;
	private String details;
	private String message;
	
	
	public ErrorDetails(LocalDate timestamp, String message, String details) {
		super();
		this.timestamp = timestamp;
		this.details = details;
		this.message = message;
	}

	public LocalDate getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(LocalDate timestamp) {
		this.timestamp = timestamp;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	

}
