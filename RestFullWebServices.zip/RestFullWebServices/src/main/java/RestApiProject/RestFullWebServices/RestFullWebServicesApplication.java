package RestApiProject.RestFullWebServices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestFullWebServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestFullWebServicesApplication.class, args);
	}

}
