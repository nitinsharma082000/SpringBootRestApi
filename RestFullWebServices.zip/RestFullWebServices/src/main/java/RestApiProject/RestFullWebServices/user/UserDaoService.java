package RestApiProject.RestFullWebServices.user;

import java.time.LocalDate;
import java.util.*;

import org.springframework.stereotype.Component;

@Component
public class UserDaoService {
	
	private static List<User> users=new ArrayList<>();
	private static int usercount=0;
	
	static {
		
		users.add(new User(usercount++,"Nitin", LocalDate.now().minusYears(12)));
		users.add(new User(usercount++,"Ayush", LocalDate.now().minusYears(30)));
		users.add(new User(usercount++,"Shantanu", LocalDate.now().minusYears(40)));
		
	}
	
	
	public List<User> findAll() {
		
		return users;
		
	}
	
	
	public User save(User user) {
		user.setId(usercount++);
		users.add(user);
		return user;
		
	}
	
	public User findOne(int id) {
		
		User search=null;
		int flag=0;
		
		for (User a:users) {
			if(a.getId()==id) {
				search=a;
				flag=1;	
			}
		}
		
		if( flag==1) return search;
		else return null;
		
	}
	
	public void deletebyId(int id) {
		
		for (User a:users) {
			if(a.getId()==id) {
				users.remove(a);
				break;
			}
		}
	
		
	}
	
	

}
